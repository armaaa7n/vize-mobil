class Stylist {
  final String name;
  final String salon;
  final String rating;
  final String image;

  Stylist(this.name, this.salon, this.rating, this.image);
}
