class Service {
  final String serviceName;
  final String time;
  final String price;

  Service(this.serviceName, this.time, this.price);
}
