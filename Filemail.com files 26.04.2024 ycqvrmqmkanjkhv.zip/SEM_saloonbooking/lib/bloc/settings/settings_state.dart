class SettingsState {
  final bool darkMode;
  String language;


  SettingsState({
    this.darkMode = false,
    this.language = "en", 
    });
}